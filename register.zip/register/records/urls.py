from django.urls import path
from . import views

urlpatterns = [
    path('signin/',views.signin_fn,name='signin'),
    path('signup/',views.signup_fn,name='signup'),
    path('',views.records_fn,name='records'),
    path('logout/',views.logout_fn,name='logout'),
    path('editrecord/<int:id>',views.editrecords_fn,name='editrecord'),
    path('deleterecord/<int:id>',views.deleterecord_fn,name='deleterecord'),
]