from .models import user_data,records_model
from django import forms
from django.contrib.auth.forms import UserCreationForm

# Form Registratiion

class signup_form(UserCreationForm):
    class Meta:
        model = user_data
        fields = ['username','first_name','last_name','email','phone']


#Records
class records_form(forms.ModelForm):
    class Meta:
        model = records_model
        fields = '__all__'

#Records Edit
class editrecord_form(forms.ModelForm):
    class Meta:
        model = records_model
        fields = '__all__'