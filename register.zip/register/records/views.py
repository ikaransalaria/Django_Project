from django.shortcuts import render,HttpResponseRedirect
from .forms import signup_form,records_form,editrecord_form
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from .models import records_model,user_data
from django.contrib.auth.models import User
# Create your views here.

#Sign IN Function
def signin_fn(request):
 if not request.user.is_authenticated:
    if request.method=='POST':
        fm = AuthenticationForm(request=request, data=request.POST)
        if fm.is_valid():
            uname = fm.cleaned_data['username']
            upass = fm.cleaned_data['password']
            user = authenticate(username=uname,password=upass)
            if user is not None:
                login(request,user)
                return HttpResponseRedirect('/')
    else:
        fm = AuthenticationForm()
    return render(request,'signin.html',{'form':fm})
 else:
     return HttpResponseRedirect('/')

#Logout

def logout_fn(request):
    logout(request)
    return HttpResponseRedirect('/signin/')

#Sign UP Function
def signup_fn(request):
 if not request.user.is_authenticated:
    if request.method == "POST":
        fm = signup_form(request.POST)
        if fm.is_valid():
            fm.save()
    else:
        fm = signup_form()
    return render(request,'signup.html',{'form':fm})
 else:
     return HttpResponseRedirect('/')


#RECORDS 

def records_fn(request):
 if request.user.is_authenticated:
    data = records_model.objects.all() 
    if request.method == "POST":
     if request.user.is_superuser == True:
        fm = records_form(request.POST)
        us = request.user.is_superuser
     else:
        fm = records_form(request.POST)
        us = None
        if fm.is_valid():
         fm.save()
    else:
     if request.user.is_superuser == True:
        fm = records_form()
        us = request.user.is_superuser
     else:
        fm = records_form()
        us = None
    return render(request,'records.html',{'name':request.user,'form':fm,'records':data,'user':us})
 else:
     return HttpResponseRedirect('/signin/')


# Edit RECORDS

def editrecords_fn(request, id):
    pi = records_model.objects.get(pk=id)
    if request.method == "POST":
        # pi = records_model.objects.get(pk=id)
        fm = editrecord_form(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
            HttpResponseRedirect('/signin/')
    else:
        # pi = records_model.objects.get(pk=id)
        fm = editrecord_form(instance=pi)
    return render(request,'editrecord.html',{'id':id,'form':fm})


# Delete Records

def deleterecord_fn(request, id):
    pi = records_model.objects.get(pk=id)
    pi.delete()
    return HttpResponseRedirect('/signin/')