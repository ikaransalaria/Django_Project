from django.shortcuts import render,HttpResponseRedirect
from .forms import reg_form
from .models import reg_model
# Create your views here.
def fn_app(request):
    data = reg_model.objects.all()
    if request.method == 'POST':
        fm = reg_form(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            reg = reg_model(name=nm, email=em, password=pw)
            reg.save()
            fm = reg_form()
    else:
        fm = reg_form()
    return render(request, 'form.html',{'form':fm,'fm_data':data})

# delete
def data_del(request, id):
    if request.method == 'POST':
        var_pi = reg_model.objects.get(pk=id)
        var_pi.delete()
        return HttpResponseRedirect('/reg')
