from django.urls import path
from . import views

urlpatterns = [
    path('',views.fn_app, name="appform"),
    path('delete/<int:id>/',views.data_del, name='deletedaa')

]