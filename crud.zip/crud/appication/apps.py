from django.apps import AppConfig


class AppicationConfig(AppConfig):
    name = 'appication'
