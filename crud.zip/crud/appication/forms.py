from .models import reg_model
from django import forms

class reg_form(forms.ModelForm):
    class Meta:
        model = reg_model
        fields = ['name','email','password']