from django.shortcuts import render, HttpResponseRedirect
from .forms import userform,SignUpForm
from .models import user
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout
# Create your views here.
def fn_add(request):
    st_data = user.objects.all()
    if request.method == 'POST':
        fm = userform(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            reg = user(name=nm, email=em, password=pw)
            reg.save()
            fm = userform()
    else:
        fm = userform()
    if request.user.is_authenticated:
        return render(request, 'enroll/addandshow.html',{'form':fm,'stud':st_data,'name':request.user})
    else:
        return HttpResponseRedirect('/auth_login/')

#update 
def data_update(request , id):
    if request.method == 'POST':
        pi = user.objects.get(pk=id)
        fm = userform(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
            return HttpResponseRedirect('/')
    else:
        pi = user.objects.get(pk=id)
        fm = userform(instance=pi)
    return render(request,'enroll/updatestudent.html',{'form':fm})

# delete
def data_del(request, id):
    if request.method == 'POST':
        var_pi = user.objects.get(pk=id)
        var_pi.delete()
        return HttpResponseRedirect('/')

#  Auth Sign Up Function

def sign_up(request):
    if request.method == 'POST':
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            fm.save()
            messages.success(request,'Your are registered successfully')
            return HttpResponseRedirect('/auth_login/')      
    else:
        if request.user.is_authenticated:
            return HttpResponseRedirect('/auth_login/')
        else:
            fm = SignUpForm()
    return render(request,'enroll/auth_form.html',{'auth_form':fm})

# Auth Sign in FUnction

def sign_in(request):
 if not request.user.is_authenticated: 
    if request.method == "POST":
      fm = AuthenticationForm(request=request, data= request.POST)
      if fm.is_valid():
          uname = fm.cleaned_data['username']
          upass = fm.cleaned_data['password']
          user = authenticate(username=uname, password=upass)
          if user is not None:
              login(request,user)
              return HttpResponseRedirect('/')
    else:
        fm = AuthenticationForm()
    return render(request,'enroll/auth_login.html',{'auth_login':fm})
 else:
    return HttpResponseRedirect('/')

#logot Function

def auth_logout(request):
    logout(request)
    return HttpResponseRedirect('/auth_login/')
